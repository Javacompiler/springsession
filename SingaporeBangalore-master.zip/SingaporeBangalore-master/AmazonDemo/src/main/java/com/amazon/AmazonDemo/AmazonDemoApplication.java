package com.amazon.AmazonDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amazon.sabari.SabariService;



//@SpringBootConfiguration
//@EnableAutoConfiguration
//@ComponentScan

//Switch to switch on the Boot
@SpringBootApplication
@RestController
@ImportResource("classpath:/spring/spring-config.xml")
@PropertySource("classpath:/sabari.properties")
//@PropertySources()
public class AmazonDemoApplication extends SpringBootServletInitializer {

	/*public static void main(String[] args) {
		SpringApplication.run(AmazonDemoApplication.class, args);
	}*/
	
	//@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		
		return builder.sources(AmazonDemoApplication.class);
		
	}
	
	
	@GetMapping("/welcome")
	public String welcomeMethod() {
		return "Welcome to Spring Boot!";
	}
	
	@Autowired
	SailorComponent sailorComponent;
	
	@Autowired
	SabariService sabariService;
	
	@GetMapping("/sailor")
	public String sailor() {
		return sailorComponent.getSailorDetails();
	}
	
	
	@GetMapping("/saba")
	public String sabari() {
		return sabariService.welcomeSabari();
	}
	
}
