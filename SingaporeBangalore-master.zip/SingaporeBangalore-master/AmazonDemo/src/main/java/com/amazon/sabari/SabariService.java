package com.amazon.sabari;

import org.springframework.stereotype.Service;

@Service
public class SabariService {

	public String welcomeSabari() {
		return "Hi Sabari Welcome";
	}
}
