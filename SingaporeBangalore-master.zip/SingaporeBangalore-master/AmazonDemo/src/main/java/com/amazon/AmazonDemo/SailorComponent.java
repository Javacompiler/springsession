package com.amazon.AmazonDemo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix= "sailor")
public class SailorComponent {

	//SpEL
	//@Value("${sailor.name}")
	private String name;
	//@Value("${sailor.age}")
	private int age;
	//@Value("${sailor.grade}")
	private float grade;		
	
	
	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public int getAge() {
		return age;
	}




	public void setAge(int age) {
		this.age = age;
	}




	public float getGrade() {
		return grade;
	}




	public void setGrade(float grade) {
		this.grade = grade;
	}




	public String getSailorDetails() {
		return  name+age+grade;
	}
	

	
	
	
}


